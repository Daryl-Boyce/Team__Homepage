<?php
   echo  
   ' 
   <!-- Bottom nav -->
    <div class="bottom__nav">
        <div class="bottom__nav__license">
        
            <img src="assets\att__logo.png" alt="att logo">
            <img src="assets\xero__logo.png" alt="xero certified logo">

            <p>
            AAT licensed accountant with over 15
            years of accountancy experience.
           
            My services include bookkeeping, full accounts
            production,payroll, VAT and tax.
            </p>

        </div>
        <div class="bottom__nav__contact__us">
            <h3>
                Contact us
            </h3>
            <p>
                sharon wray accountancy services
                unit 4 silver farm
                silver street
                bestthorpe
                norfolk, NR17 2NY
                Tel: 01953687077 or 07894067905
            </p>
        </div>
        <div class="bottom__nav__sections">
            <h3>
                Sections
            </h3>
            <ul>
                <li><a href="/pair-project/index.php">My Services</a></li>
                <li><a href="/pair-project/accountants.php">Switch Accountants</a></li>
                <li><a href="/pair-project/faqs.php">FAQ&apos;s</a></li>
                <li><a href="/pair-project/contact.php">Contact Us</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms &amp; Conditions</a></li>
            </ul>
        </div>
    </div>
    <!---------------->
   <!-- Footer -->
     <footer>

        <hr>
        <p>
         copyright &copy; sharon wray accountancy services. 
         all rights reserved 2018. -sitemap
        <p>
     </footer>
     <!------------>
     <!---------->
'
?>